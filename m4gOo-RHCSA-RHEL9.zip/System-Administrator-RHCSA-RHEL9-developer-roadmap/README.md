
# STUDYING FOR RHCSA (RHEL9.0)

Most of the knowledge I learned came from the internet. For me, it is important to continue contributing and helping others, as this strengthens our community. Therefore, I have compiled information from different sources to learn and prepare myself well for the RHCSA exam.

I have decided to challenge myself with a hands-on certification in Linux. I have been studying for both versions, so please note that the ***Topics_notes and Reviews*** files I have covered are applicable to RHEL 8 and 9.

This experience has boosted my confidence after successfully passing the exam.🎉

I wish you all the best and good luck! Have fun!


