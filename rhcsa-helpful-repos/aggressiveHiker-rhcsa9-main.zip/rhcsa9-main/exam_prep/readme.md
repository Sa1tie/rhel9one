# Exam Prep
This area contains a practice task list consisting of 43 tasks that cover every exam objective. Use these two files for running through the tasks:
- system_info.md
- ordered_task_list.md

### Solutions
The solutions_ordered_task_list.md file shows comprehensive solutions to every task, including explanations for a lot of it.

### Exam Objective Mapping
The intent of objective_based_task_list.md is to show the mapping between exam objectives and tasks. It is currently in-progress and should be ignored.